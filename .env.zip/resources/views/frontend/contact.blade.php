<x-guest-layout>

<div> This is Ccontact Page </div>

</x-guest-layout>
