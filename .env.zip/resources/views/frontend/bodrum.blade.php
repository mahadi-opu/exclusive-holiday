<x-guest-layout>

    <div> This is Bodrum  Page </div>

    </x-guest-layout>
