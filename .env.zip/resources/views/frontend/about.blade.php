<x-guest-layout>
    <div>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia excepturi odit sit aperiam provident at
        eligendi
        molestiae optio officiis necessitatibus in culpa, nemo qui dolorem autem ratione harum doloremque laboriosam.
    </div>
</x-guest-layout>
