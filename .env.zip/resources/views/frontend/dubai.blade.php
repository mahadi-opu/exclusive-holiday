<x-guest-layout>

    <div> This is Dubai Page </div>

</x-guest-layout>
